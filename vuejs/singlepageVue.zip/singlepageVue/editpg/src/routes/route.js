import home from '../components/HelloWorld.vue';
import AddEd from '../components/addedit.vue'


export const routes=[
    // {path:'/user',component:home},
    {path:'/user',component:AddEd},
    {path:'*',redirect:'/user'}
]