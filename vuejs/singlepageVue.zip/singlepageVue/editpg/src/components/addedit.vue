<template>
  <div>
    <table class="table">
      <thead>
        <tr>
          <th>Name</th>
          <th>EmpId</th>
          <th>Role</th>
          <th>PreOrganization</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in arr" :key="item.EmpId">
          <td>
            <b-form-input
              v-validate="'required|alpha'"
              v-model="item.Name"
              placeholder="Enter Name"
              name="Name"
            ></b-form-input>
            <span>{{ errors.first('Name') }}</span>
          </td>
          <td>
            <b-form-input
              v-validate="'required|numeric'"
              v-model="item.EmpId"
              placeholder="Enter EmpId"
              name="EmpId"
            ></b-form-input>
            <span>{{ errors.first('EmpId') }}</span>
          </td>
          <td>
            <b-form-input
              v-validate="'required|alpha'"
              v-model="item.Role"
              placeholder="Enter Role"
              name="Role"
            ></b-form-input>
            <span>{{ errors.first('Role') }}</span>
          </td>
          <td>
            <b-form-input
              v-validate="'required|alpha'"
              v-model="item.PreOrganization"
              placeholder="Enter PreOrganization"
              name="PreOrganization"
            ></b-form-input>
            <span>{{ errors.first('PreOrganization') }}</span>
          </td>
          <td v-if="addShow">
            <b-button variant="info" @click="addLine(item)">+ {{addShow}}</b-button>
          </td>
          <td v-else>
            <b-button variant="info" @click="removeData(item.EmpId)">-</b-button>
          </td>
        </tr>
      </tbody>
    </table>
    <div>
      <tr>
        <td>
          <b-button style="float:right" variant="info" @click="postData()">Submit</b-button>
        </td>
      </tr>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  data() {
    return {
      arr: [],
      form: {
        Name: "",
        EmpId: "",
        Role: "",
        PreOrganization: ""
      },
      postDt: [],
      addShow: true
    };
  },
  mounted() {
    this.addLine();
  },
  methods: {
    postData: function() {
      console.log("postdt>>>>>>>>>>>" + this.postDt);
      //console.log(data);
      return axios
        .post("http://localhost:5000/api/v1/post", this.postDt, {
          headers: {
            "Content-type": "application/json"
          }
        })
        .then(response => {
          console.log("result  :" + response);
          this.addLine();
        })
        .catch(e => {
          console.log(e);
        });
    },
    addLine: function(value) {
      //this.arr.length-1 ? (this.addShow = false) : (this.addShow = true);
      console.log(this.arr.length);

      //   if (this.arr.length - 1) {
      //     this.addShow = true;
      //   } else {
      //     this.addShow = false;
      //   }
      let checkEmptyLines = this.arr.filter(line => line.number === null);
      if (!value === 1 || value === undefined) {
        console.log("no user");
      } else {
        console.log("hai");
        this.postDt.push(value);
        console.log(" post data", this.postDt);
        // this.addShow = true;
      }
      if (checkEmptyLines.length >= 1 && this.lines.length > 0) return;
      return this.arr.push({
        Name: null,
        EmpId: null,
        Role: null,
        PreOrganization: null
      });
    },
    removeData: function() {
      const getindex = this.arr.findIndex(Element => Element.Id == Id);
      this.arr.splice(getindex, 1);
    }
  }
};
</script>

<style>
</style>
