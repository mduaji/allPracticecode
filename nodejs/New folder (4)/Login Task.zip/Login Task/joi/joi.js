const joi = require('joi');

//const postvalidation 
module.exports = joi.object().keys({
    name: joi.string().alphanum().min(3).max(20).required(),
    email: joi.string().email().lowercase().required(),
    mobileNo: joi.string().regex(/^\d{10}$/).required(),
    age: joi.number().integer(5).max(100).required(),
    gender: joi.string().min(4).max(6).required(),
    address: joi.string().required(),
    password: joi.string().max(7).required()
});
//module.exports = { postvalidation };




