const nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        email: 'ajith2@gmail.com',
        password:'ajith'
    }
});
var mailoption = {
    from: 'ajith@gmail.com',
    to: 'aji@gmail.com',
    subject: 'Send The Password',
    test: 'password  : assdkdj'
};
transporter.sendMail(mailoption, (err, info) => {
    if (!info) {
        return err
    }
    else {
        console.log('email sent');
    }
})