const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const con = require('../model/model');
const joi = require('joi')
const generator = require('generate-password');
const schema = require('../joi/joi');
const nodemailer = require('nodemailer');

const postRegister = (req, res) => {
    let sql = "INSERT INTO datadb set ?";
    const dynamicPassword = generator.generate({
        length: 7,
        numbers: true,
        uppercase: true
    });
    console.log(dynamicPassword);
    let value = {
        name: req.body.name,
        email: req.body.email,
        mobileNo: req.body.mobileNo,
        age: req.body.age,
        gender: req.body.gender,
        address: req.body.address,
        password: dynamicPassword
    }
    // joi.validate(value, schema, (err, validationresult) => {
    //     validationresult.password = bcrypt.hashSync(validationresult.password);
    //     if (err) {
    //         res.status(405).send('joi validation error');
    //     } else {
            con.query(sql, value, (err, result) => {
                if (err) throw err;
                else {
                   // res.json(result);
                    // res.redirect('/auth');
                    var transporter = nodemailer.createTransport({
                        service: 'gmail',
                        // auth: {
                        //     email: 'ajith2@gmail.com',
                        //     password: 'ajith'
                        // }
                    });
                    var mailoption = {
                        from: 'ajith@gmail.com',
                        to: 'mduaji10@gmail.com',
                        subject: 'Send The Password',
                        test: `password  :${dynamicPassword}`
                    };
                    transporter.sendMail(mailoption, (err, info) => {
                        if (!info) {
                           console.log('failed');
                        }
                        else {
                            console.log('email sent' + info.res);
                        }
                    });
                    res.json(result);
                }
            });
        }
//     });
// };
const postauth = (req, res) => {
    const email1 = req.body.email;
    var sql = `SELECT * FROM datadb where email=?`;
    con.query(sql, [email1], function (err, userInfo) {
        if (!userInfo) {
            res.status(405);
            res.send('the userinfo is not found');
        }
        else
            bcrypt.compare(req.body.password, userInfo[0].password, (err, result) => {
                if (!result) {
                    return res.status(404).json({
                        status: "Error",
                        failed: 'Unauthorized Access'
                    });
                }
                else {
                    const JWTToken = jwt.sign({
                        email: userInfo.email
                    },
                        'secret',
                        {
                            expiresIn: '2h'
                        }
                    );
                    return res.status(200).send({
                        status: "success",
                        data: userInfo,
                        token: JWTToken
                    });
                };
            });
    });
}
con.connect((err) => {
    if (err)
        console.log('db connection error');
    else {
        console.log('db connected');
    }
});

module.exports = { postRegister, postauth };