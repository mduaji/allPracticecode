//imports the chai  
const chai = require("chai");
//imports the chai-http 
const chaihttp = require('chai-http');
//imports th chai assertion should 
const should = chai.should();
//imports the index.js 
const server = require('../user');
//chai use chaihttp middleware
chai.use(chaihttp);

describe('Users', () => {

    it('should take less than 500ms', function (done) {
        this.timeout(500);
        setTimeout(done, 300);
    });
    var token = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwcm9qZWN0SWQiOjUsIl9pZCI6IjVjYTM1YTkwZDZlM2ZjMGYzNDFmZjJlZiIsImlhdCI6MTU1NDIwOTQ1MywiZXhwIjoxNTU0MjE2NjUzfQ.jg-GTBG2DwMaPiD6a4YpRkAbpgYWntW6-Iedgl6lSM8"

    //GET route to retrieve all the details.
    describe('get the details', () => {
        it('/get', function (done) {
            chai.request(server)
                .get('/api/v1/get')
                .set('Authorization', token)
                .end((err, res) => {
                    res.should.have.status(200);
                    res.body.should.be.a('array');
                    done();
                });
        });
    });
    //GET route to retrieve all the particular ID details.
    describe('get the ID details', () => {
        describe('Get the given ProjectId', () => {
            it('/the id not found', function (done) {
                chai.request(server)
                    .get('/api/v1/query?projectId=344')
                    .set('Authorization', token)
                    .send('the given id is not found')
                    .end((err, res) => {
                        res.should.have.status(404);
                        done();
                    });
            });
            it('/get the vaild id', function (done) {
                chai.request(server)
                    .get('/api/v1/query?projectId=1')
                    .set('Authorization', token)
                    .end((err, res) => {
                        res.should.have.status(200);
                        res.body.should.be.a('array');
                        // res.body.should.have.property('projectId');
                        // res.body.should.have.property('projectName');
                        // res.body.should.have.property('projectManager');
                        done();
                    });
            });
        });
        describe('Get the given Project Manager', () => {
            it('/the given Manager name is not found', function (done) {
                chai.request(server)
                    .get('/api/v1/query?projectManager=akilasmsad')
                    .set('Authorization', token)
                    .send('the given id is not found')
                    .end((err, res) => {
                        res.should.have.status(404);
                        done();
                    });
            });
            it('/get the given project Manager', function (done) {
                chai.request(server)
                    .get('/api/v1/query?projectManager=gogul')
                    .set('Authorization', token)
                    .end((err, res) => {
                        res.should.have.status(200);
                        res.body.should.be.a('array');
                        // res.body.should.have.lengthOf(10);
                        // res.body.should.have.property('projectId');
                        done();
                    });
            });
        });
        describe('Get the Given Project Name', () => {
            it('/the given project name is not found', function (done) {
                chai.request(server)
                    .get('/api/v1/query?projectName=vv')
                    .set('Authorization', token)
                    .send('the given id is not found')
                    .end((err, res) => {
                        res.should.have.status(404);
                        done();
                    });
            });
            it('/get the given projectname', function (done) {
                chai.request(server)
                    .get('/api/v1/query?projectName=datamigration')
                    .set('Authorization', token)
                    .end((err, res) => {
                        res.should.have.status(200);
                        res.body.should.be.a('array');
                        // res.body.should.have.lengthOf(10);
                        // res.body.should.have.property('projectId');
                        done();
                    });
            });
        });
    });
    //POST route to insert all the details.
    describe('should be Post the details', () => {

        it('/should not post without all column ', function (done) {
            let data = {
                projectId: 11,
                projectName: "collection",
                startDate: "2019-04-01",
                projectDuration: 60,
                totalProjectHours: 500,
                projectManager: "anu",
                projectDesc: "collection data",
                password: "ajith123"
            }
            chai.request(server)
                .post('/api/v1/post')
                .set('Authorization', token)
                .send('enter vaild id & this Id is already use')
                .end((err, res) => {
                    res.should.have.status(404);
                    done();
                });
        });
        it('/should be insert the all column ', function (done) {
            let data = {
                projectId: 10,
                projectName: "collectiondatas",
                startDate: "2019-04-01",
                endDate: "2019-12-01",
                projectDuration: 60,
                totalProjectHours: 500,
                projectManager: "anusiya1",
                projectDesc: "collection data",
                password: "ajith123"
            }
            chai.request(server)
                .post('/api/v1/post')
                .set('Authorization', token)
                .send(data)
                .end((err, res) => {
                    res.should.have.status(200);
                    res.body.should.be.a('object');
                    //res.should.be.json;
                    // res.body.should.have.property('projectId');
                    // res.body.should.have.property('projectName');
                    // res.body.should.have.property('projectManager');
                    done();
                });
        });
    });

    //PUT route to Update the details.
    describe(' Put the details', () => {
        describe('should be update the given project id ', () => {
            it('/should not update the data without all column', function (done) {
                let data = {
                    projectName: "salary",
                    startDate: "2019-01-05",
                    endDate: "2019-07-01",
                    projectDuration: 30,
                    totalProjectHours: 500,
                    projectDesc: "salary update",
                    password: "ajith1234"
                }
                chai.request(server)
                    .put('/api/v1/query?projectId=335')
                    .set('Authorization', token)
                    .send('Should not Update without all column')
                    .end((err, res) => {
                        res.should.have.status(404);
                        res.body.should.be.a('object');
                        done();
                    });
            })
            it('/should be update the particular id ', function (done) {
                let data = {
                    projectName: "salary",
                    startDate: "2019-04-01",
                    endDate: "2019-12-01",
                    projectDuration: 60,
                    totalProjectHours: 500,
                    projectManager: "aaji",
                    projectDesc: "collection data",
                    password: "aji122"
                }
                chai.request(server)
                    .put('/api/v1/query?projectId=3')
                    .set('Authorization', token)
                    .send(data)
                    .end((err, res) => {
                        res.should.have.status(200);
                        res.body.should.be.a('object');
                        done();
                    });
            });

        });
        describe('should be update the given project Manager Name ', () => {
            it('/should not update without all column ', function (done) {
                let data = {
                    projectName: "salary",
                    startDate: "2019-04-01",
                    endDate: "2019-12-01",
                    totalProjectHours: 500,
                    projectDesc: "collection data",
                    password: "ajay12"
                }
                chai.request(server)
                    .put('/api/v1/query?projectManager=anusiya1')
                    .set('Authorization', token)
                    .send('should not update without all column')
                    .end((err, res) => {
                        res.should.have.status(404);
                        res.body.should.be.a('object');
                        done();
                    });
            });
            it('/should be update the particular id ', function (done) {
                let data = {
                    projectId: 10,
                    projectName: "collection",
                    startDate: "2019-04-01",
                    endDate: "2019-12-01",
                    projectDuration: 60,
                    totalProjectHours: 500,
                    projectDesc: "collection data",
                    password: "jeyam12"
                }
                chai.request(server)
                    .put('/api/v1/query?projectManager=dani12')
                    .set('Authorization', token)
                    .send(data)
                    .end((err, res) => {
                        res.should.have.status(200);
                        res.body.should.be.a('object');
                        done();
                    });
            });

        });
        describe('should be update the given projectName ', () => {
            it('/should not update the data without all column', function (done) {
                let data = {
                    projectId: 12,
                    startDate: "2019-01-05",
                    endDate: "2019-07-01",
                    projectDuration: 30,
                    totalProjectHours: 500,
                    projectDesc: "salary update",
                    password: "pavi123"
                }
                chai.request(server)
                    .put('/api/v1/query?projectName=coll')
                    .set('Authorization', token)
                    .send('Should not Update without all column')
                    .end((err, res) => {
                        res.should.have.status(404);
                        res.body.should.be.a('object');
                        done();
                    });
            });
            it('/should be update the particular id ', function (done) {
                let data = {
                    projectId: 9,
                    startDate: "2019-04-01",
                    endDate: "2019-12-01",
                    projectDuration: 60,
                    totalProjectHours: 500,
                    projectManager: "kumar",
                    projectDesc: "collection data",
                    password: "akiln12"
                }
                chai.request(server)
                    .put('/api/v1/query?projectName=collectiondatas1')
                    .set('Authorization', token)
                    .send(data)
                    .end((err, res) => {
                        res.should.have.status(200);
                        res.body.should.be.a('object');
                        done();
                    });
            });

        });

    });
    //Delete route to delete the ID details
    describe('/delete the user', () => {
        describe('/should be delete the Given project id ', () => {
            it('/the delete id is not found', function (done) {
                chai.request(server)
                    .delete('/api/v1/query?projectId=50')
                    .set('Authorization', token)
                    .send('delete the details will error & Enter the Valid Id')
                    .end((err, res) => {
                        res.should.have.status(404);
                        res.body.should.be.a('object');
                        done();
                    });
            });
            it('/should be delete the particular id', function (done) {
                chai.request(server)
                    .delete('/api/v1/query?projectId=8')
                    .set('Authorization', token)
                    .end((err, res) => {
                        res.should.have.status(200);
                        res.body.should.be.a('object');
                        //res.body.result.should.have.property('deletedCount').eql(1);
                        //res.body.result.should.have.property('n').eql(1);
                        done();
                    });
            });
        })
        describe('/should be delete the Given Project Name', () => {
            it('/the delete id is not found', function (done) {
                chai.request(server)
                    .delete('/api/v1/query?projectName=ajex')
                    .set('Authorization', token)
                    .send('delete the details will error & Enter the Valid Id')
                    .end((err, res) => {
                        res.should.have.status(404);
                        res.body.should.be.a('object');
                        done();
                    });
            });
            it('/should be delete the particular id', function (done) {
                chai.request(server)
                    .delete('/api/v1/query?projectName=collectdatas')
                    .set('Authorization', token)
                    .end((err, res) => {
                        res.should.have.status(200);
                        res.body.should.be.a('object');
                        done();
                    });
            });
        })
        describe('/should be delete the Given Project Manager Name', () => {
            it('/the delete Manager Name is not found', function (done) {
                chai.request(server)
                    .delete('/api/v1/query?projectManager=ajex')
                    .set('Authorization', token)
                    .send('delete the details will error & Enter the Valid Id')
                    .end((err, res) => {
                        res.should.have.status(404);
                        res.body.should.be.a('object');
                        done();
                    });
            });
            it('/should be delete the particular Manager Name', function (done) {
                chai.request(server)
                    .delete('/api/v1/query?projectManager=anusiya1')
                    .set('Authorization', token)
                    .end((err, res) => {
                        res.should.have.status(200);
                        res.body.should.be.a('object');
                        done();
                    });
            });
        });

    });
    describe('register the details', () => {
        describe('should register the details', () => {
            it('register without any data', function (done) {
                let data = {
                    projectId: 11,
                    projectName: "collection",
                    startDate: "2019-04-01",
                    projectDuration: 60,
                    totalProjectHours: 500,
                    projectManager: "anu",
                    projectDesc: "collection data",
                    password: "ajith123"
                }
                chai.request(server)
                    .post('/users/register')
                    .send('Should not register without any data')
                    .end((req, res) => {
                        res.should.have.status(404);
                        done();
                    });
                it('register the all data', function (done) {
                    let data = {
                        projectId: 11,
                        password: "ajith123"
                    }
                    chai.request(server)
                        .post('/users/register')
                        .send(data)
                        .end((req, res) => {
                            res.should.have.status(200);
                            res.body.should.be.a('object');
                            done();
                        })
                })
            })
        })
    });


})
