module.exports = {
    "secret" : "passwordsecret"
} 